# trash > 2024-07-04 1:27am
https://universe.roboflow.com/hk-butti/trash-dmnfc

Provided by a Roboflow user
License: CC BY 4.0

